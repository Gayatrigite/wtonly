<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Catalogue</title>
</head>
<body>
    <?php 
    include("dbconnect.php");

    // Check if the connection is successful
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Query to retrieve books
    $query = "SELECT * FROM books";
    $result = mysqli_query($db, $query);

    // Check if the query was successful
    if ($result) {
        if (mysqli_num_rows($result) > 0) {
            ?>
            <table border="2" align="center" cellpadding="5" cellspacing="5">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Price</th>
                </tr>
                <?php while($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row["id"];?></td>
                        <td><?php echo $row["title"];?></td>
                        <td><?php echo $row["author"];?></td>
                        <td><?php echo $row["price"];?></td>
                    </tr>
                <?php } ?>
            </table>
        <?php } else {
            echo "<center>No books found in the library.</center>";
        }
    } else {
        // Display an error message if the query fails
        echo "Error: " . mysqli_error($db);
    }

    // Close the database connection
    mysqli_close($db);
    ?>   
</body>
</html>
