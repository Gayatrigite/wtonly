<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
</head>
<body>
    <h1>Welcome to our Bookstore</h1>
    <p>Explore our collection and find your next favorite book!</p><br>
    <p>Click for Registration</p>
    <a href="registration.php">Register</p>
</body>
</html>