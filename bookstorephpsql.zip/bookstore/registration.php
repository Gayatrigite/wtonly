<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration</title>
</head>
<body>
    <h1>User Registration</h1>

    <?php
    include("dbconnect.php");

    // Initialize variables
    $username = $password = "";
    $usernameErr = $passwordErr = "";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Validate username
        if (empty($_POST["username"])) {
            $usernameErr = "Username is required";
        } else {
            $username = test_input($_POST["username"]);
        }

        // Validate password
        if (empty($_POST["password"])) {
            $passwordErr = "Password is required";
        } else {
            $password = password_hash(test_input($_POST["password"]), PASSWORD_DEFAULT);
        }

        // Check if there are no errors before inserting into the database
        if (empty($usernameErr) && empty($passwordErr)) {
            $query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
            $result = mysqli_query($db, $query);

            if ($result) {
                echo "<p>Registration Successful! WELCOME, $username!</p>";
            } else {
                echo "<p>Error: " . mysqli_error($db) . "</p>";
            }
        }
    }

    // Function to sanitize and validate input
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="username">Username:</label>
        <input type="text" name="username" required>
        <span class="error"><?php echo $usernameErr; ?></span>
        <br>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <span class="error"><?php echo $passwordErr; ?></span>
        <br>
        <br>
        <input type="submit" value="Register">
    </form>
<br>
    <a href="catalogue.php">Book Catalogue</a>
</body>
</html>
