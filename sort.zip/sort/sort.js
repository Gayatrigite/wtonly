// Sorts the integer array and displays the result
function sortIntegerArray() {
    var input = $("#integerInput").val();
    var integerArray = input.split(",").map(Number);
    var sortedArray = integerArray.sort(function(a, b) {
      return a - b;
    });
    $("#sortedIntegerArray").text(sortedArray);
  }
  
  // Searches for a specific integer in the array and displays the result
  function searchIntegerArray() {
    var input = $("#integerInput").val();
    var integerArray = input.split(",").map(Number);
    var searchValue = parseInt(prompt("Enter the value to search for:"));
    var foundIndex = integerArray.indexOf(searchValue);
    if (foundIndex > -1) {
      $("#sortedIntegerArray").text("Found at index: " + foundIndex);
    } else {
      $("#sortedIntegerArray").text("Value not found");
    }
  }
  
  // Sorts the named entity array and displays the result
  function sortNamedEntityArray() {
    var input = $("#namedEntityInput").val();
    var namedEntityArray = input.split(",");
    var sortedArray = namedEntityArray.sort();
    $("#sortedNamedEntityArray").text(sortedArray);
  }
  
  // Searches for a specific named entity in the array and displays the result
  function searchNamedEntityArray() {
    var input = $("#namedEntityInput").val();
    var namedEntityArray = input.split(",");
    var searchValue = prompt("Enter the value to search for:");
    var foundIndex = namedEntityArray.indexOf(searchValue);
    if (foundIndex > -1) {
      $("#sortedNamedEntityArray").text("Found at index: " + foundIndex);
    } else {
      $("#sortedNamedEntityArray").text("Value not found");
    }
  }
  
  // Attach event handlers to the buttons
  $(document).ready(function() {
    $("#integerSortBtn").click(sortIntegerArray);
    $("#integerSearchBtn").click(searchIntegerArray);
    $("#namedEntitySortBtn").click(sortNamedEntityArray);
    $("#namedEntitySearchBtn").click(searchNamedEntityArray);
  });